// Inkluderingsdirektiv:
#include "button.hpp"

/***************************************************************************
* button: Konstruktor f�r objekt av strukten button. Objektet i fr�ga
*         initieras och aktuell PIN reserveras samt s�tts till inport.
***************************************************************************/
gpio::button::button(const std::uint8_t pin, const std::uint8_t active_high,
                     const gpio::event event, const bool event_detection_enabled)
{
   this->m_pin = pin;
   this->set_active_high(active_high);
   this->m_event = event;
   this->m_event_detection_enabled = event_detection_enabled;
   gpio::init(this->m_pin, gpio::direction::in);
   return;
}

/***************************************************************************
* is_pressed: Indikerar ifall tryckknappen �r nedtryckt.
***************************************************************************/
bool gpio::button::is_pressed(void)
{
   if (this->m_active_high)
   {
      return static_cast<bool>(gpio::read(this->m_pin));
   }
   else
   {
      return !static_cast<bool>(gpio::read(this->m_pin));
   }
}

/***************************************************************************
* event_is_detected: Indikerar ifall ett specifikt event har �gt rum p�
*                    tryckknappens insignal, under f�ruts�ttning att
*                    eventdetektering har aktiverats.
***************************************************************************/
bool gpio::button::event_is_detected(void)
{
   if (!this->m_event_detection_enabled)
   {
      return false;
   }
   else
   {
      return gpio::event_detected(this->m_pin, this->m_event, this->m_last_value);
   }

   return false;
}

/***************************************************************************
* enable_event_detection: Aktiverar eventdetektering p� valbar flank
*                         (stigande, fallande eller b�da flanker).
***************************************************************************/
void gpio::button::enable_event_detection(const gpio::event new_event)
{
   this->m_event = new_event;
   this->m_event_detection_enabled = true;
   return;
}

/***************************************************************************
* set_active_high: S�tter aktiv h�g signal, d�r allt �ver noll r�knas
*                  r�knas som en logisk etta. Senast uppm�tta v�rde s�tts
*                  till aktiv l�g som default.
***************************************************************************/
void gpio::button::set_active_high(const std::uint8_t new_active_high)
{
   if (new_active_high)
   {
      this->m_active_high = 1;
      this->m_last_value = 0;
   }
   else
   {
      this->m_active_high = 0;
      this->m_last_value = 1;
   }
}