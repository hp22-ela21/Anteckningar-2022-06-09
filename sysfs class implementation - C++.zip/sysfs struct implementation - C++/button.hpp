#ifndef BUTTON_H_
#define BUTTON_H_

// Inkluderingsdirektiv:
#include "gpio.hpp"

/***************************************************************************
* button: Klass f�r enkel implementering av tryckknappar, d�r insignalen
*         kan l�sas av och monitoreras f�r eventdetektering. Aktivt h�g
*         signal �r valbar och eventdetektering kan togglas vid behov.
*         Reservation av tryckknappens PIN kan tas bort manuellt via 
*         medlemsfunktionen release.
***************************************************************************/
class gpio::button
{
protected:
   std::uint8_t m_pin = 0x00; // Aktuellt PIN-nummer.
   bool m_event_detection_enabled = false; // Indikerar ifall eventdetektering �r aktiverat.
   gpio::event m_event = gpio::event::rising_edge; // Aktuellt event som monitoreras.
   std::uint8_t m_last_value = 0; // Senaste avl�sta insignal.
   std::uint8_t m_active_high = 1; // Aktivt h�g signal.
public:
   button(void) {}
   button(const std::uint8_t pin, const std::uint8_t active_high = 1, 
          const gpio::event event = gpio::event::rising_edge, 
          const bool event_detection_enabled = false);
   ~button(void) { }  
   button& operator = (button&) = delete; // Tilldelningsoperator raderad.
   void release(void) { gpio::release(this->m_pin); }
   std::uint8_t pin(void) { return this->m_pin; }
   bool event_detection_is_enabled(void) { return this->m_event_detection_enabled; }
   gpio::event event(void) { return this->m_event; }
   std::uint8_t last_value(void) { return this->m_last_value; }
   bool is_pressed(void);
   bool event_is_detected(void);
   void enable_event_detection(const gpio::event new_event);
   void disable_event_detection(void) { this->m_event_detection_enabled = false; }
   void set_active_high(const std::uint8_t new_active_high);
};

#endif /* BUTTON_H_ */