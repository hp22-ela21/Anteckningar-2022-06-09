// Inkluderingsdirektiv:
#include "gpio.hpp"

/***************************************************************************
* Icke namngivna namnrymder motsvarar statiska funktioner i C, vilket
* inneb�r att synligheten f�r dess inneh�ll str�cker sig till aktuell fil.
***************************************************************************/
namespace
{
   /***************************************************************************
   * file_write: Skriver ett textstycke till en fil.
   ***************************************************************************/
   void file_write(const std::string& filepath, const std::string& s)
   {
      std::ofstream fstream(filepath, std::ios::out);

      if (!fstream)
      {
         std::cerr << "Could not open file at path " << filepath << "!\n\n";
      }
      else
      {
         fstream << s;
      }

      return;
   }

   /***************************************************************************
   * file_read: L�ser en rad med text fr�n en fil och lagrar i en str�ng.
   ***************************************************************************/
   void file_read(const std::string& filepath, std::string& s)
   {
      std::ifstream fstream(filepath, std::ios::in);

      if (!fstream)
      {
         std::cerr << "Could not open file at path " << filepath << "!\n\n";
      }
      else
      {
         std::getline(fstream, s);
      }

      return;
   }

   /***************************************************************************
   * export_pin: Reserverar aktuell PIN f�r anv�ndning.
   ***************************************************************************/
   void export_pin(const std::uint8_t pin)
   {
      const std::string filepath = "/sys/class/gpio/export";
      file_write(filepath, std::to_string(pin));
      return;
   }

   /***************************************************************************
   * unexport_pin: Tar bort reservation av PIN efter anv�ndning.
   ***************************************************************************/
   void unexport_pin(const std::uint8_t pin)
   {
      const auto filepath = "/sys/class/gpio/unexport";
      file_write(filepath, std::to_string(pin));
      return;
   }

   /***************************************************************************
   * set_direction: S�tter datariktning p� aktuell PIN.
   ***************************************************************************/
   void set_direction(const std::uint8_t pin, const gpio::direction direction)
   {
      const auto filepath = "/sys/class/gpio/gpio" + std::to_string(pin) + "/direction";

      if (direction == gpio::direction::out)
      {
         file_write(filepath, "out");
      }
      else
      {
         file_write(filepath, "in");
      }

      return;
   }
}

/***************************************************************************
* init: Reserverar aktuell PIN och v�ljer datariktning.
***************************************************************************/
void gpio::init(const std::uint8_t pin, const gpio::direction direction)
{
   export_pin(pin);
   set_direction(pin, direction);
   return;
}

/***************************************************************************
* write: S�tter utsignal p� aktuell PIN. 
***************************************************************************/
void gpio::write(const std::uint8_t pin, const std::uint8_t value)
{
   const auto filepath = "/sys/class/gpio/gpio" + std::to_string(pin) + "/value";

   if (value)
   {
      file_write(filepath, "1");
   }
   else
   {
      file_write(filepath, "0");
   }

   return;
}

/***************************************************************************
* read: Returnerar insignal fr�n en given PIN.
***************************************************************************/
std::uint8_t gpio::read(const std::uint8_t pin)
{
   const auto filepath = "/sys/class/gpio/gpio" + std::to_string(pin) + "/value";
   std::string s;
   file_read(filepath, s);

   if (s == "1")
   {
      return 1;
   }
   else
   {
      return 0;
   }
}

/***************************************************************************
* delay: Genererar f�rdr�jning m�tt i millisekunder.
***************************************************************************/
void gpio::delay(const std::size_t delay_time)
{
   usleep(delay_time * 1000);
   return;
}

/***************************************************************************
* blink: Blinkar utsignalen p� aktuell PIN.
***************************************************************************/
void gpio::blink(const std::uint8_t pin, const std::size_t delay_time)
{
   gpio::write(pin, 1);
   gpio::delay(delay_time);
   gpio::write(pin, 0);
   gpio::delay(delay_time);
   return;
}

/***************************************************************************
* gpio_event_detected: Indikerar ifall ett specifikt event har �gt rum
*                      p� aktuell PIN och uppdaterar senast avl�sta
*                      insignal via ing�ende argument last_value. En
*                      f�rdr�jning p� 50 ms implementeras f�r att minimera
*                      p�verkan av kontaktstudsar.
***************************************************************************/
bool gpio::event_detected(const std::uint8_t pin, const gpio::event event, std::uint8_t& last_value)
{
   const auto previous_value = last_value;
   const auto current_value = gpio::read(pin);
   last_value = current_value;

   if (current_value == previous_value) return false;
   gpio::delay(50);

   if (event == gpio::event::rising_edge)
   {
      if (current_value && !previous_value) return true;
      else return false;
   }
   else if (event == gpio::event::falling_edge)
   {
      if (!current_value && previous_value) return true;
      else return false;
   }
   else if (event == gpio::event::both_edges)
   {
      if (current_value != previous_value) return true;
      else return false;
   }

   return false;
}

/***************************************************************************
* release: Tar bort reservation fr�n aktuell PIN.
***************************************************************************/
void (*gpio::release)(const std::uint8_t pin) = &unexport_pin;
