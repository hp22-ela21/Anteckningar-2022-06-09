#ifndef GPIO_HPP_
#define GPIO_HPP_

// Inkluderingsdirektiv:
#include <iostream>
#include <string>
#include <fstream>
#include <unistd.h>

/***************************************************************************
* gpio: Namnrymd inneh�llande funktionalitet f�r GPIO-implementering via
*       sysfs i form av funktioner, klasser samt enumerationsklasser.
***************************************************************************/
namespace gpio
{
   // Enumerationsklasser:
   enum class direction { in, out };
   enum class event { rising_edge, falling_edge, both_edges };

   // Externa funktioner:
   void init(const std::uint8_t pin, const gpio::direction direction);
   void write(const std::uint8_t pin, const std::uint8_t value);
   std::uint8_t read(const std::uint8_t pin);
   void delay(const std::size_t delay_time);
   void blink(const std::uint8_t pin, const std::size_t delay_time);
   bool event_detected(const std::uint8_t pin, const gpio::event event, std::uint8_t& last_value);

   // Funktionspekare:
   extern void (*release)(const std::uint8_t pin);

   // Klasser:
   class button;
   class led;
}

#endif /* GPIO_HPP_ */