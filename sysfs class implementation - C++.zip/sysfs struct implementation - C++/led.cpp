// Inkluderingsdirektiv:
#include "led.hpp"

/***************************************************************************
* led: Konstruktor f�r objekt av strukten led. Objektet initieras, f�ljt
*      av att aktuell PIN reserveras och s�tts till utport. Lysdioden 
*      h�lls sl�ckt vid start som default, vilket dock �r valbart.
***************************************************************************/
gpio::led::led(const std::uint8_t pin, const std::uint8_t default_value)
{
   this->m_pin = pin;
   gpio::init(this->m_pin, gpio::direction::out);

   if (default_value)
   {
      this->on();
   }
   else
   {
      this->off();
   }

   return;
}

/***************************************************************************
* on: T�nder lysdiod.
***************************************************************************/
void gpio::led::on(void)
{
   gpio::write(this->m_pin, 1);
   this->m_enabled = true;
   return;
}

/***************************************************************************
* off: Sl�cker lysdiod.
***************************************************************************/
void gpio::led::off(void)
{
   gpio::write(this->m_pin, 0);
   this->m_enabled = false;
   return;
}

/***************************************************************************
* toggle: Togglar lysdiod.
***************************************************************************/
void gpio::led::toggle(void)
{
   if (this->m_enabled)
   {
      this->off();
   }
   else
   {
      this->on();
   }
   return;
}

/***************************************************************************
* led_blink: Blinkar lysdiod med valbar f�rdr�jningstid.
***************************************************************************/
void gpio::led::blink(const std::size_t delay_time)
{
   this->toggle();
   gpio::delay(delay_time);
   return;
}