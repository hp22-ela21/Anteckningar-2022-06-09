#ifndef LED_HPP_
#define LED_HPP_

// Inkluderingsdirektiv:
#include "gpio.hpp"

/***************************************************************************
* led: Klass f�r enkel implementering av lysdioder, som kan t�ndas,
*      sl�ckas, togglas samt blinkas. Reservation av aktuell PIN kan
*      tas bort manuellt via medlemsfunktionen release (vid kopiering
*      av led-objekten i exempelvis en vektor kommer annars reservationen
*      r�ka tas bort efter till�gg ifall detta genomf�rs vid destruktorn).
***************************************************************************/
class gpio::led
{
protected:
   std::uint8_t m_pin = 0; // Aktuellt PIN-nummer.
   bool m_enabled = false; // Indikerar ifall lysdioder �r t�nd eller inte.
public:
   led(void) { }
   led(const std::uint8_t pin, const std::uint8_t default_value = 0);
   ~led(void) { this->off(); }
   led& operator = (led&) = delete; // Tilldelningsoperator raderad.
   void release(void) { this->off(); gpio::release(this->m_pin); }
   std::uint8_t pin(void) { return this->m_pin; }
   bool enabled(void) { return this->m_enabled; }
   void on(void);
   void off(void);
   void toggle(void);
   void blink(const std::size_t delay_time);
};

#endif /* LED_HPP_ */