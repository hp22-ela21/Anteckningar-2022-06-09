/*************************************************************************************
* GPIO-implementering f�r Raspberry Pi med det virtuella filsystemet sysfs i C++.
*
* Kompilera programmet och skapa en k�rbar fil d�pt example5 enligt nedan:
* g++ *.cpp -o example5 -Wall
*
* K�r sedan programmet via f�ljande kommando:
* ./example5
**************************************************************************************/

// Inkluderingsdirektiv:
#include "header.hpp"
#include <vector>

/***************************************************************************
* leds_blink: Blinkar lysdioder fram�t och bak�t i en slinga. F�rst sker
*             blinkning fram�t fr�n f�rsta till sista lysdiod. D�refter
*             sker blinkning bak�t fr�n n�st sista till f�rsta lysdioden.
***************************************************************************/
static void leds_blink(std::vector<gpio::led>& leds, const size_t delay_time)
{
   for (auto& i : leds)
   {
      i.on();
      gpio::delay(delay_time);
      i.off();
   }
   
   for (auto i = leds.end() - 2; i > leds.begin(); --i)
   {
      i->on();
      gpio::delay(delay_time);
      i->off();
   }
   return;
}

/***************************************************************************
* leds_off: Sl�cker ett antal lysdioder.
***************************************************************************/
static void leds_off(std::vector<gpio::led>& leds)
{
   for (auto& i : leds)
   {
      i.off();
   }
   return;
}

/***************************************************************************
* main: Ansluter lysdioder till PIN 17, 22 och 23 samt en tryckknapp till
*       PIN 27. Eventdetektering sker p� tryckknappens insignal, d�r
*       lysdioderna togglas mellan att blinka var 100:e millisekund eller
*       vara sl�ckta vid stigande flank (n�r tryckknappen trycks ned).
*       F�r att enkelt implementera blinkning samt avst�ngning av ett
*       valfritt antal lysdioder, s� lagras lysdioderna i en vektor,
*       d�r fler lysdioder kan l�ggas till vid behov.
***************************************************************************/
int main(void)
{
   gpio::led led1(17);
   gpio::led led2(22);
   gpio::led led3(23);

   gpio::button button1(27);
   button1.enable_event_detection(gpio::event::rising_edge);

   std::vector<gpio::led> leds { led1, led2, led3 };
   bool leds_enabled = false;

   while (1)
   {
      if (button1.event_is_detected())
      {
         leds_enabled = !leds_enabled;
      }

      if (leds_enabled)
      {
         leds_blink(leds, 100);
      }
      else
      {
         leds_off(leds);
      }
   }

   return 0;
}

