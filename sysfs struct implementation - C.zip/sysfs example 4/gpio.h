#ifndef GPIO_H_
#define GPIO_H_

/* Inkluderingsdirektiv: */
#include <stdio.h> /* Inneh�ller printf, FILE* med mera. */
#include <stdlib.h> /* Inneh�ller malloc, atoi med mera. */
#include <stdbool.h> /* Inneh�ller bool. */
#include <stdint.h> /* Inneh�ller uint8_t med mera. */
#include <unistd.h> /* Inneh�ller funktioner sleep samt usleep. */

/* Enumerationer: */
enum gpio_direction { GPIO_DIRECTION_IN, GPIO_DIRECTION_OUT };
enum gpio_event { GPIO_EVENT_RISING_EDGE, GPIO_EVENT_FALLING_EDGE, GPIO_EVENT_BOTH_EDGES };

/* Externa funktioner: */
void gpio_new(const uint8_t pin, const enum gpio_direction direction);
void gpio_write(const uint8_t pin, const uint8_t value);
uint8_t gpio_read(const uint8_t pin);
void gpio_delay(const size_t delay_time);
void gpio_blink(const uint8_t pin, const size_t delay_time);
bool gpio_event_detected(const uint8_t pin, const enum gpio_event event, uint8_t* last_value);

/* Funktionspekare: */
extern void (*gpio_delete)(const uint8_t pin);

#endif /* GPIO_H_ */




