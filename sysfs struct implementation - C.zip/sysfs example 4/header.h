#ifndef HEADER_H_
#define HEADER_H_

/* Inkluderingsdirektiv: */
#include "gpio.h"
#include "led.h"
#include "button.h"

#endif /* HEADER_H_ */