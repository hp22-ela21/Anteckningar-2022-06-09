#ifndef LED_H_
#define LED_H_

/* Inkluderingsdirektiv: */
#include "gpio.h"

/***************************************************************************
* led: Strukt f�r enkel implementering av lysdioder, som kan t�ndas, 
*      sl�ckas, togglas samt blinkas.
***************************************************************************/
struct led
{
   uint8_t pin; /* Aktuellt PIN-nummer. */
   bool enabled; /* Indikerar ifall lysdioder �r t�nd eller inte. */
};

/* Externa funktioner: */
void led_new(struct led* self, const uint8_t pin);
void led_delete(struct led* self);
struct led* led_ptr_new(const uint8_t pin);
void led_ptr_delete(struct led** self);
void led_on(struct led* self);
void led_off(struct led* self);
void led_toggle(struct led* self);
void led_blink(struct led* self, const size_t delay_time);

#endif /* LED_H_ */