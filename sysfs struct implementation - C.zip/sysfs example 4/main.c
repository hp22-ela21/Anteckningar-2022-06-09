/*************************************************************************************
* GPIO-implementering f�r Raspberry Pi med det virtuella filsystemet sysfs.
*
* Kompilera programmet och skapa en k�rbar fil d�pt example4 enligt nedan:
* gcc *.c -o example4 -Wall
*
* K�r sedan programmet via f�ljande kommando:
* ./example4
**************************************************************************************/

/* Inkluderingsdirektiv: */
#include "header.h"

/***************************************************************************
* leds_blink: Blinkar lysdioder fram�t och bak�t i en slinga. F�rst sker
*             blinkning fram�t fr�n f�rsta till sista lysdiod. D�refter
*             sker blinkning bak�t fr�n n�st sista till f�rsta lysdioden.
***************************************************************************/
static void leds_blink(struct led* leds, const size_t size, const size_t delay_time)
{
   for (register struct led* i = leds; i < leds + size; ++i)
   {
      led_on(i);
      gpio_delay(delay_time);
      led_off(i);
   }

   for (register struct led* i = leds + size - 2; i > leds; --i)
   {
      led_on(i);
      gpio_delay(delay_time);
      led_off(i);
   }
   return;
}

/***************************************************************************
* leds_off: Sl�cker ett antal lysdioder.
***************************************************************************/
static void leds_off(struct led* leds, const size_t size)
{
   for (register struct led* i = leds; i < leds + size; ++i)
   {
      led_off(i);
   }
   return;
}

/***************************************************************************
* main: Ansluter lysdioder till PIN 17, 22 och 23 samt en tryckknapp till
*       PIN 27. Eventdetektering sker p� tryckknappens insignal, d�r
*       lysdioderna togglas mellan att blinka var 100:e millisekund eller
*       vara sl�ckta vid stigande flank (n�r tryckknappen trycks ned).
*       F�r att enkelt implementera blinkning samt avst�ngning av ett
*       valfritt antal lysdioder s� lagras lysdioderna i en statisk array,
*       d�r fler lysdioder kan l�ggas till vid behov.
***************************************************************************/
int main(void)
{
   struct led led1, led2, led3;
   struct button button1;

   led_new(&led1, 17);
   led_new(&led2, 22);
   led_new(&led3, 23);

   button_new(&button1, 27);
   button_enable_event_detection(&button1, GPIO_EVENT_RISING_EDGE);

   struct led leds[] = { led1, led2, led3 };
   const size_t number_of_leds = sizeof(leds) / sizeof(struct led);
   bool leds_enabled = false;

   while (1)
   {
      if (button_event_is_detected(&button1))
      {
         leds_enabled = !leds_enabled;
      }

      if (leds_enabled)
      {
         leds_blink(leds, number_of_leds, 100);
      }
      else
      {
         leds_off(leds, number_of_leds);
      }
   }

   return 0;
}

