/* Inkluderingsdirektiv: */
#include "button.h"

/***************************************************************************
* button_new: Konstruktor f�r objekt av strukten button. Objektet i fr�ga
*        initieras och aktuell PIN reserveras samt s�tts till inport.
*        Eventdetektering st�lls in p� stigande flank som default, men
*        m�ste aktiveras innan anv�ndning. Aktiv h�g signal s�tts som
*        default till logisk etta.
***************************************************************************/
void button_new(struct button* self, const uint8_t pin)
{
   self->pin = pin;
   self->event_detection_enabled = false;
   self->event = GPIO_EVENT_RISING_EDGE;
   self->last_value = 0;
   self->active_high = 1;
   return;
}

/***************************************************************************
* button_delete: Destruktor f�r objekt av strukten button. Reservation 
*                av aktuell PIN tas bort.
***************************************************************************/
void button_delete(struct button* self)
{
   gpio_delete(self->pin);
   self->event_detection_enabled = false;
   self->event = -1;
   return;
}

/***************************************************************************
* button_ptr_new: Konstruktor f�r pekare till objekt av strukten button. 
*                 Minne allokeras f�r objektet, f�ljt av att aktuell PIN 
*                 reserveras och s�tts till inport. Eventdetektering st�lls 
*                 in p� stigande flank som default, men m�ste aktiveras 
*                 innan anv�ndning. Aktivt h�g signal s�tts till logisk 
*                 etta som default. Efter slutf�rd initiering returneras 
*                 en pekare till objektet i fr�ga.
***************************************************************************/
struct button* button_ptr_new(const uint8_t pin)
{
   struct button* self = (struct button*)malloc(sizeof(struct button));
   if (!self) return 0;
   button_new(self, pin);
   return self;
}

/***************************************************************************
* button_ptr_delete: Destruktor f�r pekare till objekt av strukten button. 
*                    Reservation av aktuell PIN tas bort, minnet f�r
*                    objektet frig�rs och pekaren i fr�ga s�tts till null.
***************************************************************************/
void button_ptr_delete(struct button** self)
{
   button_delete(*self);
   free(*self);
   *self = 0;
   return;
}

/***************************************************************************
* button_is_pressed: Indikerar ifall en tryckknapp �r nedtryckt.
***************************************************************************/
bool button_is_pressed(const struct button* self)
{
   if (self->active_high)
   {
      return (bool)gpio_read(self->pin);
   }
   else
   {
      return !((bool)gpio_read(self->pin));
   }
}

/***************************************************************************
* button_event_is_detected: Indikerar ifall ett specifikt event har �gt
*                           rum p� tryckknappens insignal, f�rutsatt att
*                           eventdetektering �r aktiverat.
***************************************************************************/
bool button_event_is_detected(struct button* self)
{
   if (self->event_detection_enabled)
   {
      return false;
   }
   else
   {
      return gpio_event_detected(self->pin, self->event, &self->last_value);
   }
}

/***************************************************************************
* button_enable_event_detection: Aktiverar eventdetektering p� valbar flank
*                                (stigande, fallande eller b�da flanker).
***************************************************************************/
void button_enable_event_detection(struct button* self, const enum gpio_event new_event)
{
   self->event = new_event;
   self->event_detection_enabled = true;
   return;
}

/***************************************************************************
* button_disable_event_detection: Inaktiverar eventdetektering.
***************************************************************************/
void button_disable_event_detection(struct button* self)
{
   self->event_detection_enabled = false;
   return;
}

/***************************************************************************
* button_set_active_high: S�tter aktiv h�g signal, d�r allt �ver noll r�knas
*                         r�knas som en logisk etta.
***************************************************************************/
void button_set_active_high(struct button* self, const uint8_t active_high)
{
   if (active_high)
   {
      self->active_high = 1;
   }
   else
   {
      self->active_high = 0;
   }
   return;
}