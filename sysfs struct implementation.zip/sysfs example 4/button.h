#ifndef BUTTON_H_
#define BUTTON_H_

/* Inkluderingsdirektiv: */
#include "gpio.h"

/***************************************************************************
* button: Strukt f�r enkel implementering av tryckknappar, d�r insignalen
*         kan l�sas av och monitoreras f�r eventdetektering. Aktivt h�g
*         signal �r valbar och eventdetektering kan togglas vid behov.
***************************************************************************/
struct button
{
   uint8_t pin; /* Aktuellt PIN-nummer. */
   bool event_detection_enabled; /* Indikerar ifall eventdetektering �r aktiverat. */
   enum gpio_event event; /* Aktuellt event som monitoreras. */
   uint8_t last_value; /* Senaste avl�sta insignal. */
   uint8_t active_high; /* Aktivt h�g signal. */
};

/* Externa funktioner: */
void button_new(struct button* self, const uint8_t pin);
void button_delete(struct button* self);
struct button* button_ptr_new(const uint8_t pin);
void button_ptr_delete(struct button** self);
bool button_is_pressed(const struct button* self);
bool button_event_is_detected(struct button* self);
void button_enable_event_detection(struct button* self, const enum gpio_event new_event);
void button_disable_event_detection(struct button* self);
void button_set_active_high(struct button* self, const uint8_t active_high);

#endif /* BUTTON_H_ */