/* Inkluderingsdirektiv: */
#include "led.h"

/***************************************************************************
* led_new: Konstruktor f�r objekt av strukten led. Objektet initieras,
*        f�ljt av att aktuell PIN reserveras och s�tts till utport. 
***************************************************************************/
void led_new(struct led* self, const uint8_t pin)
{
   self->pin = pin;
   self->enabled = false;
   gpio_new(self->pin, GPIO_DIRECTION_OUT);
   return;
}

/***************************************************************************
* led_delete: Destruktor f�r objekt av strukten led. Utsignalen p� aktuell
*             PIN s�tts till l�g samt reservation av denna tas bort.
***************************************************************************/
void led_delete(struct led* self)
{
   gpio_write(self->pin, 0);
   gpio_delete(self->pin);
   self->pin = -1;
   self->enabled = false;
   return;
}

/***************************************************************************
* led_ptr_new: Konstruktor f�r pekare till objekt av strukten led. 
*              Minne allokeras f�r objektet i fr�ga, f�ljt av att aktuell 
*              PIN initieras och s�tts till utport. Slutligen returneras
*              pekaren till objektet.
***************************************************************************/
struct led* led_ptr_new(const uint8_t pin)
{
   struct led* self = (struct led*)malloc(sizeof(struct led));
   if (!self) return 0;
   led_new(self, pin);
   return self;
}

/***************************************************************************
* led_ptr_delete: Destruktor f�r pekare till objekt av strukten led. 
*                 Utsignalen p� aktuell PIN s�tts till l�g och reservation 
*                 av denna tas bort. Minnet frig�rs sedan och pekaren 
*                 till objektet s�tts till null.
***************************************************************************/
void led_ptr_delete(struct led** self)
{
   led_delete(*self);
   free(*self);
   *self = 0;
   return;
}

/***************************************************************************
* led_on: T�nder lysdiod.
***************************************************************************/
void led_on(struct led* self)
{
   gpio_write(self->pin, 1);
   self->enabled = true;
   return;
}

/***************************************************************************
* led_off: Sl�cker lysdiod.
***************************************************************************/
void led_off(struct led* self)
{
   gpio_write(self->pin, 0);
   self->enabled = false;
   return;
}

/***************************************************************************
* led_toggle: Togglar lysdiod.
***************************************************************************/
void led_toggle(struct led* self)
{
   if (self->enabled)
   {
      led_off(self);
   }
   else
   {
      led_on(self);
   }
   return;
}

/***************************************************************************
* led_blink: Blinkar lysdiod med valbar f�rdr�jningstid.
***************************************************************************/
void led_blink(struct led* self, const size_t delay_time)
{
   led_toggle(self);
   gpio_delay(delay_time);
}